function searchProducts(event) {

    event.preventDefault();

    const searchInput = document.getElementById('search-input');

    const searchTerm = searchInput.value;

 

    // Redireciona para a página de pesquisa com os resultados

    window.location.href = `pesquisa.html?query=${searchTerm}`;

  }

 

  // Captura o evento de envio do formulário de pesquisa

  document.getElementById('search-form').addEventListener('submit', searchProducts);