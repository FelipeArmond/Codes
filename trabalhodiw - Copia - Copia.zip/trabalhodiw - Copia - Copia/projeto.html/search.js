// Obtém o termo de pesquisa da URL

const urlParams = new URLSearchParams(window.location.search);

const searchTerm = urlParams.get('query');




// Faz uma requisição GET para obter a lista completa de produtos

fetch('https://fakestoreapi.com/products')

  .then(response => response.json())

  .then(products => {

    const filteredProducts = products.filter(product =>

      product.title.toLowerCase().includes(searchTerm.toLowerCase())

    );




    const productList = document.getElementById('product-list');




    // Limpa o conteúdo anterior

    productList.innerHTML = '';




    // Renderiza os produtos encontrados na página

    filteredProducts.forEach(product => {

      const productItem = document.createElement('div');

      productItem.innerHTML = `

        <img src="${product.image}" alt="${product.title}">

        <h3>${product.title}</h3>

        <p>Price: $${product.price}</p>

        <p>Rating: ${product.rating.rate}</p>

        <a href="detalhes.html?id=${product.id}">Detalhes</a>

      `;

      productList.appendChild(productItem);

    });

  });

