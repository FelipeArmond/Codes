const urlParams = new URLSearchParams(window.location.search);

const searchTerm = urlParams.get('id');

fetch(`https://fakestoreapi.com/products/${searchTerm}`)

    .then(response => response.json())

    .then(product => {
        const flor = document.getElementById('girassol');
        flor.innerHTML = `

        <img src="${product.image}" alt="${product.title}">

        <h3>${product.title}</h3>

        <p>Preço: $${product.price}</p>

        <p>Nota: ${product.rating.rate}</p>
        
        <p>Descrição : ${product.description}</p>
        <p>Categoria: ${product.category}</p>
        

      `;
    });