function searchProducts(event) {

  event.preventDefault();

  const searchInput = document.getElementById('search-input');

  const searchTerm = searchInput.value;



  // Redireciona para a página de pesquisa com os resultados

  window.location.href = `pesquisa.html?query=${searchTerm}`;

}



// Captura o evento de envio do formulário de pesquisa

document.getElementById('search-form').addEventListener('submit', searchProducts);



fetch('https://fakestoreapi.com/products')
  .then((response) => response.json())
  .then((products) => {
    const productList = document.getElementById("listadeprodutos");

    // Renderiza os produtos na página
    const row = document.createElement("div");
    row.className = "row card-deck";

    products.forEach((product) => {
      const productItem = document.createElement("div");
      productItem.className = "col-sm-4 col-md-4 col-lg-3";

      productItem.innerHTML = `
        <div class="card">
          <img src="${product.image}" class="card-img-top" alt="Imagem do produto">
          <div class="card-body">
            <h5 class="card-title">${product.title}</h5>
            <p class="card-text">Preço: $${product.price}</p>
            <a href="detalhes.html?id=${product.id}" class="btn btn-primary">Detalhes</a>
          </div>
        </div>
      `;

      row.appendChild(productItem);
    });

    productList.appendChild(row);
  });


 